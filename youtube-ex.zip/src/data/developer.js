export const developerText = [
  {
    img: "https://yt3.ggpht.com/JuRcVt9OFQgqh7UL1LjihpVLEbjdNXt3tGq-IQfqRMT8wVXgWg_tzyz0S_GVsgqkB3ucBC5fqeY=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "조코딩 JoCoding",
    channelAddress: "https://www.youtube.com/@jocoding",
    channelId: "UCQNE2JmbasNYbjGAcuBiRRg"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_lbqqh0NSFeq6P1F-6qRycC37MtiGyMjZFVsZ4J-c6C474=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "생활코딩",
    channelAddress: "https://www.youtube.com/@coohde",
    channelId: "UCvc8kv-i5fvFTJBFAk6n1SA"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_kZGbEvWmB_2CZMcZVcCpjFsiQNVQZEehF8jinP6zlFJ7s=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "노마드 코더 Nomad Coders",
    channelAddress: "https://www.youtube.com/@nomadcoders",
    channelId: "UCUpJs89fSBXNolQGOYKn0YQ"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_mfA6OVWyw6v7dpbO5NvjkAzsH4q8G0nCcF2eaf9lOmvLGO=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "얄팍한 코딩사전",
    channelAddress: "https://www.youtube.com/@yalco-coding",
    channelId: "UC2nkWbaJt1KQDi2r2XclzTQ"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_nwJ1atCtmd4bkIhKvnjnY0cVqehB44xMmyVJmSFqXiJ8c=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "코딩애플",
    channelAddress: "https://www.youtube.com/@codingapple",
    channelId: "UCSLrpBAzr-ROVGHQ5EmxnUg"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_n_8hS5BGHDs1aNbljYPCJOP-lPUAtOIbTsg2AqjWyyDt4=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "드림코딩",
    channelAddress: "https://www.youtube.com/@dream-coding",
    channelId: "UC_4u-bXaba7yrRz_6x6kb_w"
  },
  {
    img: "https://yt3.ggpht.com/JuRcVt9OFQgqh7UL1LjihpVLEbjdNXt3tGq-IQfqRMT8wVXgWg_tzyz0S_GVsgqkB3ucBC5fqeY=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "조코딩 JoCoding",
    channelAddress: "https://www.youtube.com/@jocoding",
    channelId: "UCQNE2JmbasNYbjGAcuBiRRg"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_lbqqh0NSFeq6P1F-6qRycC37MtiGyMjZFVsZ4J-c6C474=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "생활코딩",
    channelAddress: "https://www.youtube.com/@coohde",
    channelId: "UCvc8kv-i5fvFTJBFAk6n1SA"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_kZGbEvWmB_2CZMcZVcCpjFsiQNVQZEehF8jinP6zlFJ7s=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "노마드 코더 Nomad Coders",
    channelAddress: "https://www.youtube.com/@nomadcoders",
    channelId: "UCUpJs89fSBXNolQGOYKn0YQ"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_mfA6OVWyw6v7dpbO5NvjkAzsH4q8G0nCcF2eaf9lOmvLGO=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "얄팍한 코딩사전",
    channelAddress: "https://www.youtube.com/@yalco-coding",
    channelId: "UC2nkWbaJt1KQDi2r2XclzTQ"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_nwJ1atCtmd4bkIhKvnjnY0cVqehB44xMmyVJmSFqXiJ8c=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "코딩애플",
    channelAddress: "https://www.youtube.com/@codingapple",
    channelId: "UCSLrpBAzr-ROVGHQ5EmxnUg"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_n_8hS5BGHDs1aNbljYPCJOP-lPUAtOIbTsg2AqjWyyDt4=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "드림코딩",
    channelAddress: "https://www.youtube.com/@dream-coding",
    channelId: "UC_4u-bXaba7yrRz_6x6kb_w"
  },
  {
    img: "https://yt3.ggpht.com/JuRcVt9OFQgqh7UL1LjihpVLEbjdNXt3tGq-IQfqRMT8wVXgWg_tzyz0S_GVsgqkB3ucBC5fqeY=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "조코딩 JoCoding",
    channelAddress: "https://www.youtube.com/@jocoding",
    channelId: "UCQNE2JmbasNYbjGAcuBiRRg"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_lbqqh0NSFeq6P1F-6qRycC37MtiGyMjZFVsZ4J-c6C474=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "생활코딩",
    channelAddress: "https://www.youtube.com/@coohde",
    channelId: "UCvc8kv-i5fvFTJBFAk6n1SA"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_kZGbEvWmB_2CZMcZVcCpjFsiQNVQZEehF8jinP6zlFJ7s=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "노마드 코더 Nomad Coders",
    channelAddress: "https://www.youtube.com/@nomadcoders",
    channelId: "UCUpJs89fSBXNolQGOYKn0YQ"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_mfA6OVWyw6v7dpbO5NvjkAzsH4q8G0nCcF2eaf9lOmvLGO=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "얄팍한 코딩사전",
    channelAddress: "https://www.youtube.com/@yalco-coding",
    channelId: "UC2nkWbaJt1KQDi2r2XclzTQ"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_nwJ1atCtmd4bkIhKvnjnY0cVqehB44xMmyVJmSFqXiJ8c=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "코딩애플",
    channelAddress: "https://www.youtube.com/@codingapple",
    channelId: "UCSLrpBAzr-ROVGHQ5EmxnUg"
  },
  {
    img: "https://yt3.googleusercontent.com/ytc/AIdro_n_8hS5BGHDs1aNbljYPCJOP-lPUAtOIbTsg2AqjWyyDt4=s176-c-k-c0x00ffffff-no-rj-mo",
    name: "드림코딩",
    channelAddress: "https://www.youtube.com/@dream-coding",
    channelId: "UC_4u-bXaba7yrRz_6x6kb_w"
  },
]