import youtube01 from "../assets/img/youtube/youtube01.png";
import youtube02 from "../assets/img/youtube/youtube02.png";
import youtube03 from "../assets/img/youtube/youtube03.png";
import youtube04 from "../assets/img/youtube/youtube04.png";
import youtube05 from "../assets/img/youtube/youtube05.png";

export const youtubeText = [
//복붙하여 20개 만듬
    {
        title: "01 유튜브 사이트 만들기",
        img: youtube01,
        author: "admin",
        videoId: "OKZXYgAgtyw",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "02 유튜브 사이트 만들기",
        img: youtube02,
        author: "admin",
        videoId: "OKZXYgAgtyw",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "03 유튜브 사이트 만들기",
        img: youtube03,
        author: "admin",
        videoId: "OKZXYgAgtyw",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "04 유튜브 사이트 만들기",
        img: youtube04,
        author: "admin",
        videoId: "OKZXYgAgtyw",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "05 유튜브 사이트 만들기",
        img: youtube05,
        author: "admin",
        videoId: "OKZXYgAgtyw",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },
]