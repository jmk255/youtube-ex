import port01 from "../assets/img/port/port01.png";
import port02 from "../assets/img/port/port02.png";
import port03 from "../assets/img/port/port03.png";
import port04 from "../assets/img/port/port04.png";
import port05 from "../assets/img/port/port05.png";

export const portfolioText = [
//복붙하여 20개 만듬
    {
        title: "프레임워크로 구축하는 포트폴리오 사이트 | 셋팅하기",
        img: port01,
        author: "admin",
        videoId: "2ZiZlEvtWgM",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "프레임워크로 구축하는 포트폴리오 사이트 | 레이아웃",
        img: port02,
        author: "admin",
        videoId: "2ZiZlEvtWgM",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "프레임워크로 구축하는 포트폴리오 사이트 | 헤더",
        img: port03,
        author: "admin",
        videoId: "2ZiZlEvtWgM",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "프레임워크로 구축하는 포트폴리오 사이트 | 인트로",
        img: port04,
        author: "admin",
        videoId: "2ZiZlEvtWgM",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "프레임워크로 구축하는 포트폴리오 사이트 | 포트폴리오",
        img: port05,
        author: "admin",
        videoId: "2ZiZlEvtWgM",
        date: "2024.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },
]