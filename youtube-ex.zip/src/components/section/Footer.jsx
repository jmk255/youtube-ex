import React from 'react'

const Footer = () => {
  return (
    <footer id='footer' role='contentinfo'>
      footer
    </footer>
  )
}

export default Footer