import React from 'react'
import Main from '../components/section/Main'

const Website = () => {
  return (
    <Main
      title="웹표준 사이트"
      description="웹표준 사이트 튜토리얼입니다">
      Website
    </Main>
  )
}

export default Website