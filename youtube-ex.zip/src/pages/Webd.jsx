import React from 'react'
import Main from '../components/section/Main'

const Webd = () => {
  return (
    <Main
      title="웹디자인 기능사"
      description="웹디자인 기능사 튜토리얼입니다">
      Webd
    </Main>
  )
}

export default Webd