import React from 'react'
import Main from '../components/section/Main'

const Port = () => {
  return (
    <Main
      title="포트폴리오 사이트"
      description="포트폴리오 사이트 튜토리얼 입니다">
      Port
    </Main>
  )
}

export default Port