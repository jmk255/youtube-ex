import React from 'react'
import Main from '../components/section/Main'

const Video = () => {
  return (
    <Main
      title="유튜브 비디오 영상"
      description="유튜브 비디오 영상을 볼 수 있습니다">
      Video
    </Main>
  )
}

export default Video